def calc_shipping():
    print("calc_shipping")