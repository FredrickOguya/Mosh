def contact_customer():
    pass