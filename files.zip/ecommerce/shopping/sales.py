def calc_tax():
    pass

def calc_shipping():
    pass

if __name__ == "__name__":
    print("sales started")
    calc_tax
